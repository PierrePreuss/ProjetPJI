/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
var global = (function(){ return this; }).call(null);

