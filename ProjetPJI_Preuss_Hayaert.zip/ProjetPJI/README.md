# ProjetPJI
Projet PJI dans le cadre de la première année de Master Informatique à Lille 1.

Rendez vous du 15/01


Rendez vous du 22/01


Appel t�l�phonique avec Etienne Ollion le 29/01:


Semaine du 29/01 au 5/02 :

01/02

- Nous avons travaill� sur la biblioth�que Rapaheljs de javaScript. Nous savons faire plusieurs formes g�om�triques, et aussi des vecteurs (path) ce qui est utilis� pour r�aliser l'h�micycle)

- Nous avons �labor� en nous aidant d'internet d'un 'camembert' utilisant la biblioth�que Raphael. Pour le moment, on se sert de donn�es inscrites dans le fichiers .html.
Nous allons travaill� d�s demain pour savoir comment importer un fichier csv en javasript et utilis� ensuite ces donn�es.

- Dans le dossier www, le fichier index.html est un fichier servant � tester des fonctions ou � approfondir plusieurs notios.

- Dans les fichiers pie.js, jquery.js et pie.html se trouvent le code permettant de r�aliser un camembert avec une animation de type 'mouseover'. 




