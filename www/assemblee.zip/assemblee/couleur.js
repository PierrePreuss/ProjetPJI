$(document).ready(function() 
  {
  			var i=0;
			var hemi={};
			for(i=1;i<650;i++){
				var hash= "s"+i;
				if(siege[i] != 'undefined'){
					
				 hemi[hash].attr(siege[i]);
				console.log(hemi[hash]);
				}else{
					console.log(hemi[hash]);
					i++;
					 hash= "s"+i;
					hemi[hash].attr(siege[i]);
					i=i+2;
				}	
			}
			
			
			/*
			
			for(i=1;i<641;i++){
				hemi[hash].attr(siege[i]);
				
				hemi[hash]=hemi[hash].next;
			}*/
  });